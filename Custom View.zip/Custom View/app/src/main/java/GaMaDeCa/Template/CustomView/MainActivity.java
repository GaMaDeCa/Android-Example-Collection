package GaMaDeCa.Template.CustomView;
 
import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity{
    CustomView MyCustomView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //you can set the whole custom view in the screen
        MyCustomView=new CustomView(this);
        setContentView(MyCustomView);
        
        //or in a xml layout
        //setContentView(R.layout.activity_main);
        //MyCustomView=findViewById(R.id.mainCustomView);
    }
}
