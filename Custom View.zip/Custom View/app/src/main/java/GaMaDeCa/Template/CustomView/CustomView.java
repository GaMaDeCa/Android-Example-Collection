package GaMaDeCa.Template.CustomView;

import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.view.MotionEvent;
import android.util.AttributeSet;
/*
  I tried my best to explain some basic things I come across while studying Views,
  if it's hard to understand or it lacks some content or if it needs to improve in something
  please let me know contacting me(github.com/GaMaDeCa).
*/
public class CustomView extends View {
    //My custom methods, it helps a lot when creating Paints
    public Paint getPaint(int color){
        Paint p=new Paint();
        p.setColor(color);
        return p;
    }
    public Paint getPaintFill(int color){
        Paint p=getPaint(color);
        p.setStyle(Paint.Style.FILL);
        return p;
    }
    Paint arcPaint,linePaint,
          circlePaint,ovalPaint,
          pathPaint,rectPaint,textPaint;
    /*A View only needs its public constructor with the current Activity context.
    The constructor can be 3 variations(at same time or not), super(Context context,AttributeSet attrs,int defStyle)
    With attributeset we can make custom settings(attributes) in the xml of our custom view, generally the attributes are written like:
     <GaMaDeCa.Template.CustomView
         android:layout_width....
         app:customAtribute="Hello"/>
    
   You will need to set your "app:" context in your xml, this attribute can be accesed by the AttributeSet variable.*/
    public CustomView(Context context){
        super(context);
    }
    //This constructor(with AttributeSet) is necessary for an xml view
    public CustomView(Context context,AttributeSet attrs){
        super(context,attrs);
    }
    public void setPaints(){
        arcPaint=getPaint(Color.YELLOW);
        linePaint=getPaint(Color.MAGENTA);
        circlePaint=getPaint(Color.BLUE);
        ovalPaint=getPaint(Color.GRAY);
        pathPaint=getPaint(Color.GREEN);
        rectPaint=getPaint(Color.CYAN);
        textPaint=getPaint(Color.RED);
    }
    /*Creating Views require some degree of math knowledge, all the math I've seen in Views include:
       - Coordinates x,y,x2,y2 and radius(for rectangles, ovals, etc. Basic geometry)
       - Proportionality(to make the drawing fits in the screen, an 400 pixels rectangle may look bigger on some screens and smaller in others)
       - Percentage & its conversions(for arcs(100% → 360°) and the screen proportionality above)
       - RGB System(Colors, Red Green and Blue(255,255,255), each color is made in a mix with these values)
       - And sin and cos, for circle collisions or moving
    
    The screen coordinates for drawing are inside this plan(e.g. 100×100 View screen):
    
             0
    
    
    
    0                  100
    
    
    
            100
            
            
    If you draw a rectangle in the whole canvas you will have to set the coordinates like below:
     x=0    //left
     y=0    //up
     x2=100 //right
     y2=100 //down
    */
    @Override
    protected void onDraw(Canvas canvas) {
       /*
       You can draw almost anything using canvas!
       Below, some Canvas methods:
         drawArc - Draw an arc(a "curved line")
         drawColor - Fill the whole Canvas with your custom Color
         drawBitmap - Draw the image that you chose(need to load with the Bitmap class)
         drawCircle - Draw circle with centerX, centerY and Radius
         drawLine - Draw a line(x,y → x2,y2)
         drawOval - Draw a custom circle(x,y,x2,y2)
         drawPath - Draw a custom Path(a set of custom rectangles, lines, arcs and ovals)
         drawPoint - Draw a single pixel(but it is slow if you want to draw in batch)
         drawRect - Draw a rectangle or square(drawRoundRect draws a Rectangle with rounded sides)
         drawText - Draw a custom text(needs a custom text paint)
       */
       setPaints();
       //We will reuse these coordinates in each drawing, but you may create new variables for tracking a movable drawing separately
       float x,y,x2,y2;//or left,top,right,bottom
       float radius=((width+height)/2)/10;//screenProportion=screen/10
       final float middleWidth=width/2, middleHeight=height/2;
       canvas.drawColor(Color.BLACK);
       
       x=radius/2;
       y=radius*3;
       x2=radius*2;
       y2=radius*4;
       //The arc need degrees variables(360), a full arc makes a circle
       //the start value of the arc is on the left side of the "arc circle", value 0
       //and it follows into clock wise direction
       float startAngle=180+90,stepAngle=90;//I call it stepAngle but it is called sweepAngle
       //Some helpful values:
       // - 360=The whole arc(1/1)
       // - 180=Middle of the arc(1/2)
       // - 90=A quarter of the arc(1/4)
       canvas.drawArc(x,y,x2,y2,startAngle,stepAngle,true,arcPaint);
       
       //a line in the middle of height, and slight inclined
       //you can change the line width using Paint too
       linePaint.setStrokeWidth(9);
       x=middleWidth+90;
       y=middleHeight;
       x2=width;
       y2=middleHeight+300;
       canvas.drawLine(x,y,x2,y2,linePaint);
       
       //you can name a circle variable like cx,cy(centerX,centerY), since they are center coordinates
       x=middleWidth;
       y=radius*4;
       canvas.drawCircle(x,y,radius,circlePaint);
       
       //you can make the oval be a circle using a radius value(x-r,y-r,x2+r,y2+r)
       x=middleWidth-radius;
       y=0;
       x2=middleWidth+radius;
       y2=radius*4;//radius*2; for a circle
       canvas.drawOval(x,y,x2,y2,ovalPaint);
       
       //right top of the screen, width 300 and height middle of screen
       x=width-300;
       y=0;
       x2=width;
       y2=middleHeight;
       canvas.drawRect(x,y,x2,y2,rectPaint);
       
       //Text Paints may require extra configurations
       textPaint.setTextAlign(Paint.Align.CENTER); //text in center of the x,y coordinates
       textPaint.setTextSize(60); //because the default value is too small to read
       //middle of the bottom-60 screen
       x=middleWidth;
       y=height-60;
       canvas.drawText("https://github.com/GaMaDeCa",x,y,textPaint);
       
       canvas.drawPoint(x,y,getPaint(Color.CYAN));
       
       canvas.drawBitmap(getCustomBitmap(),0,middleHeight,null);//Paint can be null
       
       //Show current size values in the same View
       logText(canvas,x,y-60,"Screen(Width×Height):"+width+"×"+height+" Touch X|Y:"+touchX+" | "+touchY,30,Color.rgb(255,255,255));
        
       x=50;
       y=50;
       x2=300;
       y2=200;
       //A triangle needs the x3 and y3 too
       float x3=x,y3=400;
       Path triangleCustomPath=new Path();
       triangleCustomPath.moveTo(x,y);
       triangleCustomPath.lineTo(x2,y2);
       triangleCustomPath.lineTo(x3,y3);
       triangleCustomPath.lineTo(x,y);
       canvas.drawPath(triangleCustomPath,getPaintFill(Color.GREEN));
       
       if(hasInput){
           canvas.drawCircle(touchX,touchY,100,getPaintFill(0xffffa800));
           invalidate();//redraw method
           //with this you can make a game using invalidate using a thread with 16 millisseconds of delay
           //but with an View it would be too slow for that, use a SurfaceView with a Thread instead
       }
       super.onDraw(canvas);
    }
    //As you can see, you only need ~2 or 4 float variables with an custom paint to draw almost anything,
    //try to create an array with these values and draw an array of rectangles or circles(or anything),
    //an ArrayList or a custom class would be helpful for this.
    
    
    //Custom method for generating a custom bitmap, drawing things in it with canvas and resizing it
    //Understanding these concepts can be very helpful for resizing game sprites or generating custom images
    public Bitmap getCustomBitmap(){
        //Create the bitmap
        int bmpWidth=300,bmpHeight=300;
        Bitmap bmp=Bitmap.createBitmap(bmpWidth,bmpHeight,Bitmap.Config.ARGB_8888,true);
        
        //Draw on bitmap
        Canvas canvas=new Canvas(bmp);
        canvas.drawRect(0,0,bmp.getWidth(),bmp.getHeight(),getPaint(Color.BLUE));
        canvas.drawCircle(bmpWidth/2,bmpHeight/2,30,getPaintFill(Color.RED));
        
        //Resize the Bitmap to 500×500
        bmp=Bitmap.createScaledBitmap(bmp,500,500,false);
        /*
        bmp.set and get Pixel are methods for editing the pixels of a bitmap
        with this you can also apply your custom effects on the images or even
        generating math images(mandelbrot fractals, spirals)
        */
        return bmp;
    }
    
    public void logText(Canvas canvas,float x,float y,String text,int textSize,int textColor){
        Paint p=getPaint(textColor);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(textSize);
        canvas.drawText(text,x,y,p);
        
    }
    //Get the width and height of the View
    //You can use getWidth() or getMeasuredWidth() to get the View values too, but they may come wrong sometimes
    int width,height;
    //Everytime the screen is updated(rotated for example) these values are updated too
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        width=w;
        height=h;
        //Math.min or max its useful to get the min or max length of the screen
        super.onSizeChanged(w, h, oldw, oldh);
    }
    boolean hasInput=false;
    float touchX,touchY;
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                //On touch detected(A short time touch(with action dowm+up), is a click)
                hasInput=true;
                touchX=event.getX();
                touchY=event.getY();
                invalidate();//redraw method(duplicated)
                break;
            case MotionEvent.ACTION_MOVE:
                //On touch move(moving the finger on screen)
                touchX=event.getX();
                touchY=event.getY();
                invalidate();//redraw when moving
                break;
            case MotionEvent.ACTION_UP:
                //On touch released(For dropping action)
                hasInput=false;
                invalidate();//clear circle(TODO>Fix)
                break;
            default:
                break;
        }
        return true;//super.onTouchEvent(event);//not always return true, true is necessary when tracking the touch move
    }
}

//you may create a new View extended class with only the context constructor and the onDraw method for tests(using the examples in this class)
