package GaMaDeCa.Template.ListView;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.ArrayList;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.app.AlertDialog;
import android.widget.EditText;
import android.content.DialogInterface;
import android.content.Context;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.LinearLayout;
import android.widget.CheckBox;
import android.widget.TextView;
/*
To create an Custom ListView you will need 3 things:
 - The data for the ListView(String arrays or any other data type)
 - The Item(custom xml layout or the default android.R.layout.simple_list_item_1)
 - The Adapter(necessary for loading each xml item)
 
You will need to create your own custom item and adapter, check them:
 -res/layout/list_item.xml
 MyAdapter.java
*/
public class MainActivity extends Activity{
    ArrayList<String> ListItens;//Viewed item names
    ArrayList<Boolean> checkBoxes;//Checkbox values tracker
    ListView listView;
    MyAdapter baseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        listView=findViewById(R.id.MainListView);
        
        setData();//Load the data in ListItens
        
        baseAdapter=new MyAdapter(this,ListItens);//The adapter will need the context and the array of the data.
        baseAdapter.setCheckBoxesBool(checkBoxes); //Custom method
        listView.setAdapter(baseAdapter);
        
        /*
        //These two listeners were changed into TextView listener at MyAdapter
        //Use it only when creating a simple TextView list
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent,View view,int position,long l){
                Toast.makeText(getApplicationContext(),ListItens.get(position),Toast.LENGTH_SHORT).show();
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            public boolean onItemLongClick(AdapterView<?> parent,View view,final int position,long l){
                //Changed to TextView onLongClick in getView method at MyAdapter
                return true;
            }
        });*/
    }
    //You will have to create your own method if you're using other data types
    //If you wish to modify it you will need to modify the CustomExpandableListAdapter too
    public void setData(){
        String[] itens="Item X,Item Y,Item Z".split(",");
        ListItens=new ArrayList<String>();
        checkBoxes=new ArrayList<Boolean>();
        for(int i=1;i<=100;i++)
            ListItens.add("Item "+i);
        ListItens.addAll(Arrays.asList(getResources().getStringArray(R.array.lv_itens)));
        for(String item:itens)
            ListItens.add(item);
        for(String item:ListItens)
            checkBoxes.add(false);
    }
    //Necessary to create the ActionBar Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        return true;
    }
    //Detecting a item click in the ActionBar Menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        AlertDialog.Builder adb;
        switch(item.getItemId()){
            case R.id.add_item:
                Context ctx=this;
                adb=new AlertDialog.Builder(ctx);
                final EditText editTxtItem=new EditText(ctx);
                editTxtItem.setTextSize(30);
                final CheckBox chkBox=new CheckBox(ctx);
                LinearLayout container=new LinearLayout(ctx);
                editTxtItem.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                container.addView(chkBox);
                container.addView(editTxtItem);
                adb.setView(container);
                adb.setTitle("Add Item");
                adb.setPositiveButton("Ok",new DialogInterface.OnClickListener(){
                     public void onClick(DialogInterface di,int p){
                         String edit=editTxtItem.getText().toString();
                         if(!edit.trim().equals("")){
                            add(edit,chkBox.isChecked());
                         }
                     }
                });
                adb.setNegativeButton("Cancel",null);
                adb.create().show();
                return true;
            case R.id.print_all:
                adb=new AlertDialog.Builder(this);
                adb.setTitle(getResources().getString(R.string.print_all_itens_string));
                StringBuilder sb=new StringBuilder();
                for(int i=0;i<ListItens.size();i++){
                    sb.append(checkBoxes.get(i)+","+ListItens.get(i)+"\n");
                }
                //adb.setMessage(sb.toString());
                TextView tv=new TextView(this);
                tv.setText(sb.toString());
                tv.setTextIsSelectable(true);
                tv.setTextSize(21);
                adb.setView(tv);
                adb.setPositiveButton("Ok",null);
                adb.create().show();
                return true;
            case R.id.clear:
                ListItens.clear();
                checkBoxes.clear();
                baseAdapter.notifyDataSetChanged();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    //You may customize your own methods for adding a Item in the ListView
    public void add(String item,boolean bool){
        ListItens.add(item);
        checkBoxes.add(bool);
        baseAdapter.notifyDataSetChanged();//This updates the ListView
    }
}
