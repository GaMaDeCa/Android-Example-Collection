package GaMaDeCa.Template.ListView;

import java.util.ArrayList;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.app.AlertDialog;
import android.widget.EditText;
import android.content.DialogInterface;
import android.widget.Toast;

public class MyAdapter extends BaseAdapter{
    private Context ctx;
    private ArrayList<String> array;
    
    private final int ITEM_LAYOUT=R.layout.list_item;//the item layout
    
    public MyAdapter(Context context,ArrayList<String> ListItens){
        ctx=context;
        array=ListItens;
    }
    //Necessary methods for the ListView working
    @Override
    public int getCount() {
        return array.size();
    }
    @Override
    public Object getItem(int p){
        return array.get(p);
    }
    @Override
    public long getItemId(int p){
        return p^getCount();
    }
    /*
    This method that creates each item, here you can use
    the views in each item layout, set listeners, etc.
    */
    @Override
    public View getView(final/*final for use in a listener*/int position,View view,ViewGroup root){
        if(view==null)
            view=((LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(ITEM_LAYOUT/*R.layout.your_item*/,null);
        
        TextView tv=view.findViewById(R.id.textViewListItem);//load the TextView in the item
        tv.setText(array.get(position));
        //Show Toast message when TextView is clicked
        tv.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Toast.makeText(v.getContext(),array.get(position)+"\n"+checkBoxes.get(position),Toast.LENGTH_SHORT).show();
            }
        });
        //Long Click=Edit Item
        tv.setOnLongClickListener(new View.OnLongClickListener(){
                public boolean onLongClick(View view){
                    Context ctx=view.getContext();
                    AlertDialog.Builder adb=new AlertDialog.Builder(ctx);
                    final EditText editTxtItem=new EditText(ctx);
                    editTxtItem.setTextSize(30);
                    adb.setView(editTxtItem);
                    adb.setTitle("Edit "+array.get(position)+"?");
                    adb.setPositiveButton("Ok",new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface di,int p){
                                String edit=editTxtItem.getText().toString();
                                if(!edit.trim().equals("")){
                                    array.set(position,edit);
                                    notifyDataSetChanged();
                                }
                            }
                        });
                    adb.setNegativeButton("Cancel",null);
                    adb.create().show();
                    return true;
                }
        });
        
        //Update the checkbox array value when it's changed
        CheckBox chk=view.findViewById(R.id.listitemCheckBox);
        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton cBtn,boolean bool){
                checkBoxes.set(position,bool);
            }
        });
        boolean chkBool=checkBoxes.get(position);
        if(chkBool!=chk.isChecked())
            chk.setChecked(chkBool);
        //The view is returned into the ListView
        return view;
    }
    //Custom method for the checkbox tracking
    ArrayList<Boolean> checkBoxes;
    public void setCheckBoxesBool(ArrayList<Boolean> chkBoxs){
        checkBoxes=chkBoxs;
    }
}
