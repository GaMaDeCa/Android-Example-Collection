package GaMaDeCa.Template.ExpandableListView;

import java.util.ArrayList;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import android.widget.ExpandableListView;

/*
To create a really custom expandable list you will need to
modify the xml of the list item and the getChildView.

For example, an ExpandedListView with CheckBox in its itens, steps to make it:
  - You will need an Array of booleans(if you only want the values) or an Array of CheckBoxes(to modify it too)
  - Add the CheckBox in the xml and dont forget to put an id on it
  - Pick it using the GetChildView and the id, get its value or itself and add in your array
  - Now you just need to create a method to access it, probably the array will be an array of arrays of booleans/checkboxes(checkboxes[groupPosition][itemPosition])
*/
public class CustomExpandableListAdapter extends BaseExpandableListAdapter{
    private Context context;
    
    // If you wish you can replace the ArrayList with normal String arrays
    private ArrayList<String> groupTitles;
    private ArrayList<ArrayList<String>> expandableArrayList;
    
    //Only the context is important in the constructor, you can modify the arrays
    public CustomExpandableListAdapter(Context context,ArrayList<String> GroupTitles,ArrayList<ArrayList<String>> ExpandableArrayList){
        this.context=context;
        groupTitles=GroupTitles;
        expandableArrayList=ExpandableArrayList;
    }
    @Override
    public Object getChild(int position,int subPosition){//or group and item positions
        return expandableArrayList.get(position).get(subPosition);
    }
    @Override
    public long getChildId(int position,int expandedListPosition){
        return expandedListPosition;
    }
    //The current item
    @Override
    public View getChildView(int position,final int expandedListPosition,boolean isLastChild,View convertView,ViewGroup parent){
        if(convertView==null)
            convertView=((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.expanded_list_item,null);
        TextView expandedListTextView=convertView.findViewById(R.id.expandedListItem);
        expandedListTextView.setText((String)getChild(position,expandedListPosition));
        return convertView;
    }
    @Override
    public int getChildrenCount(int position){
        return expandableArrayList.get(position).size();
    }
    @Override
    public Object getGroup(int position){
        return groupTitles.get(position);
    }
    @Override
    public int getGroupCount(){
        return groupTitles.size();
    }
    @Override
    public long getGroupId(int position){
        return position;
    }
    //The current group of itens
    @Override
    public View getGroupView(int position,boolean isExpanded,View convertView,ViewGroup parent){
        if(convertView==null)
            convertView=((LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.expanded_list_group,null);
        TextView listTitleTextView=convertView.findViewById(R.id.expandedListGroup);
        listTitleTextView.setText((String)getGroup(position));
        return convertView;
    }
    @Override
    public boolean hasStableIds(){
        return false;
    }
    @Override
    public boolean isChildSelectable(int listPosition,int expandedListPosition){
        return true;
    }
}
