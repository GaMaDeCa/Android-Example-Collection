package GaMaDeCa.Template.ExpandableListView;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.ArrayList;
import android.content.Intent;

//What is needed to make a ExpandedListView?
// - An array of titles(Strings), "GroupTitles"
// - An array of arrays(with titles, Strings), "ExpandableArrayList"
// - An adapter that will use these arrays(in its methods), "expandableListAdapter"
// - A view, the ExpandableListView(xml or java), "expandableListView"

//Its quite similar the making of a simple ListView, except that the ListView doenst need an array of arrays.

//In this example I will use ArrayLists,
//but you can customize it in the way you like,
//for me this is one of the best options.
//The other one I've been thinking about is just creating
//an array of classes(a structure where I will set all custom data).
//Like this:
// class ExpandedArrayStruct{
//     String label;
//     String[] sublist;
// }

// Challenge yourself improving it

//import java.util.HashMap; Why not use HashMap? because .keySet() gives wrong unsorted titles!
public class MainActivity extends Activity{
    ArrayList<String> GroupTitles;
    ArrayList<ArrayList<String>> ExpandableArrayList;
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        expandableListView=findViewById(R.id.expandableListView);
        
        setDataIntoExpandableArray();
        
        expandableListAdapter=new CustomExpandableListAdapter(this,GroupTitles,ExpandableArrayList);
        expandableListView.setAdapter(expandableListAdapter);
        
        expandAll();
        
        //These commented methods identify when the group is open or closed
        /*expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener(){
            @Override
            public void onGroupExpand(int groupPosition){
                //TODO: GroupTitles(groupPosition)
            }
        });
        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener(){
            @Override
            public void onGroupCollapse(int groupPosition){
                //TODO: GroupTitles(groupPosition)
            }
        });*/
        
        //Item click
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener(){
            @Override
            public boolean onChildClick(ExpandableListView parent,View view,int groupPosition,int childPosition,long id){
                final String GroupTitle=GroupTitles.get(groupPosition),
                             ItemLabel=ExpandableArrayList.get(groupPosition).get(childPosition);
                Toast.makeText(getApplicationContext(),GroupTitle+"."+ItemLabel,Toast.LENGTH_SHORT).show();
                
                //if you wish to open another activity when the item is clicked
                //startActivity(new Intent(MainActivity.this,AnotherActivity.class));
                //dont forget to add the new activity to the AndroidManifest(<activity name=".AnotherActivity...)
                return false;
            }
        });
    }
    
    //To expand all in the start, without it the list inst expanded by default
    public void expandAll(){
        for(int i=0;i<expandableListAdapter.getGroupCount();i++)
            expandableListView.expandGroup(i);//You can expand whichever group you want, but you will need to know their index
    }
    
    //You will have to create your own method if you're using other data types
    //If you wish to modify it you will need to modify the CustomExpandableListAdapter too
    public void setDataIntoExpandableArray(){
        String[] itens={
            "Item 1",
            "Item 2",
            "Item 3",
            "Item 4",
            "Item 5",
            "Item 6",
            "Item 7",
            "Item 8",
            "Item 9"
        };
        ArrayList<String> category1=new ArrayList<String>();
        for(String item:itens)
            category1.add(item);
        
        ArrayList<String> category2=new ArrayList<String>();
        category2.addAll(category1.subList(0,6));
        
        ArrayList<String> category3=new ArrayList<String>(category2.subList(0,3));
        
        //3 categories/groups and 3 titles
        ExpandableArrayList=new ArrayList<ArrayList<String>>();
        ExpandableArrayList.add(category1);
        ExpandableArrayList.add(category2);
        ExpandableArrayList.add(category3);
        
        //Titles of ExpandableArrayList
        GroupTitles=new ArrayList<String>(
            Arrays.asList(
                new String[]{
                    "Category 1",
                    "Category 2",
                    "Category 3"
                }
            )
        );
    }
}
